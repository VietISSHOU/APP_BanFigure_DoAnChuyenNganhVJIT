package com.appquanly.japanfigure.Model.EventBus;

public class TinhTongTienEvent {
}
