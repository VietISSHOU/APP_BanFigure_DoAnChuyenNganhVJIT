package com.appquanly.japanfigure.utils;

import com.appquanly.japanfigure.Model.GioHang;
import com.appquanly.japanfigure.Model.User;

import java.util.ArrayList;
import java.util.List;

public class Utils {
    public static final String BASE_URL = "http://192.168.1.7/figure/";
    public static List<GioHang> manggiohang;
    public static List<GioHang> mangmuahang = new ArrayList<>();
    public static User user_current = new User();
}
