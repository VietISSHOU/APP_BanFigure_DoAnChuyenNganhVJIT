package com.appquanly.japanfigure.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.appquanly.japanfigure.R;

public class PopUpParadeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pop_up_parade);
    }
}