package com.appquanly.japanfigure.Interface;

import android.view.View;

public interface ImageClick_Up_Down {
    public void onImageClick(View view, int pos , int giatri);

}
